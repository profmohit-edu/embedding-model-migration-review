# Online Resource 1 -- embedding-model migration review
Project: PL-EMBED-2026-11-04
Manuscript: Embedding-model migration for retrieval: a critical review of compatibility targets and evaluation evidence
Authors: Tripti Tiwari; Mohit Tiwari (corresponding)

This is the supplement for the embedding-migration critical review only.

Run from this directory with Python 3.10 or later:
    python code/verify_supplement.py
    python code/constructed_checks.py
These commands use only the Python standard library, require no network, and regenerate the constructed results. They do not run embedding models or reproduce the reviewed papers' experiments. The 5,000 per-instance records contain metrics and certificates; underlying random vectors are regenerated from the fixed seed in the script. The four examples are fully specified in the code and results.

Evidence: 20 core study-extraction records; 26 references (including 3 conceptual/benchmark and 3 official operational sources); 4 comparison tables; 20 discovery-query strings; source manifest; 4 constructed examples; 5,000 randomized-case records.

Original full texts are not redistributed. Source URLs and hashes identify the inspected versions. Optional source acquisition requires network and pdftotext; URLs may change and current arXiv versions may differ from the inspected hash. The extraction is an AI-assisted critical interpretation, not independently adjudicated human coding. No comprehensive-search or empirical-method-ranking claim is made.

Figure reproduction additionally requires numpy and matplotlib. The primary checks above have no third-party dependencies.
